import React from 'react';
import {BrowserRouter as Router, Switch,Link,Route} from "react-router-dom";
import Sidebar from './common/utlis/js/SideBar';
import ReferenceMapping from './ReferenceMapping';
function PageLayout() {
    return (
        <>
            <section>
                <Router>
                    <div className="row">
                        <div className="col-sm-3">
                            <Sidebar />
                        </div>
                        <div className="col-sm-9">
                            <Switch>
                                <Route exact path="/">
                                    <ReferenceMapping />
                                </Route>
                            </Switch>                            
                        </div>
                    </div>
                </Router>    
            </section>
        </>
    );
}

export default PageLayout;