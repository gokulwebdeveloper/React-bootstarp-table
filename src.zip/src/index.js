import React from 'react';
import { render } from 'react-dom';
import Header from './common/utlis/js/Header';
import PageLayout from './PageLayout';
import 'bootstrap/dist/css/bootstrap.min.css';
import './common/utlis/css/main.css';
import 'react-bootstrap-table/dist/react-bootstrap-table-all.min.css';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';

function PageDisplay() {
   return (
               <div className="container-fluid">
                  <Header />   
                  <PageLayout />   
               </div>
      );
}

render(<PageDisplay />, document.getElementById('app'));
