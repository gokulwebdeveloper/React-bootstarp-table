import React from 'react';
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';
import './page.css';



const columns = [{
    dataField: 'depnumber',
    text: 'Department ID'
  }, {
    dataField: 'depname',
    text: 'Department Name'
  }, {
    dataField: 'subdepno',
    text: 'Sub - Department Number'
  }, {
    dataField: 'subdepno',
    text: 'Sub - Department Name'
  }, {
    dataField: 'classno',
    text: 'Class Number'
  },{
    dataField: 'classname',
    text: 'Class Name'
  },{
    dataField: 'subclassname',
    text: 'Class Name'
  },{
    dataField: 'subclassnbr',
    text: 'SubClass Combo Nbr'
  }, {
    dataField: 'businessArea',
    text: 'Business Area'
  }, {
    dataField: 'svp',
    text: 'SVP'
  }, {
    dataField: 'gm',
    text: 'GM'
  }, {
    dataField: 'dfm',
    text: 'DFM'
  }, {
    dataField: 'soma',
    text: 'SOMA'
  }, {
    dataField: 'dfmldap',
    text: 'DFM Ldap'
  }, {
    dataField: 'somaldap',
    text: 'SOMA Ldap'
  }, {
    dataField: 'olap',
    text: 'OLAP'
  }];

const products = [{
        depnumber: 26,
        depname: "PLUMBING",
        subdepno: "26P",
        subdepname: "PLUMBING",
        classno: "1",
        classname: "PIPE AND FITTINGS",
        subclassnumber: "2",
        subclassname: "PVC PIPE",
        subclassnbr: "26P:1:2",
        businessArea: "Building Materials",
        svp:"Bowman",
        gm:"NA",
        dfm:"Ken Johnson",
        soma:"Philip Sadler",
        dfmldap:"KXJ3FFP",
        somaldap:"PXS4DZT",
        olap:"D26P  C01 - PIPE/FTNGS"
    }, {
        depnumber: 26,
        depname: "PLUMBING",
        subdepno: "26P",
        subdepname: "PLUMBING",
        classno: "1",
        classname: "PIPE AND FITTINGS",
        subclassnumber: "2",
        subclassname: "PVC PIPE",
        subclassnbr: "26P:1:2",
        businessArea: "Building Materials",
        svp:"Bowman",
        gm:"NA",
        dfm:"Ken Johnson",
        soma:"Philip Sadler",
        dfmldap:"KXJ3FFP",
        somaldap:"PXS4DZT",
        olap:"D26P  C01 - PIPE/FTNGS"
    }, {
        depnumber: 26,
        depname: "PLUMBING",
        subdepno: "26P",
        subdepname: "PLUMBING",
        classno: "1",
        classname: "PIPE AND FITTINGS",
        subclassnumber: "2",
        subclassname: "PVC PIPE",
        subclassnbr: "26P:1:2",
        businessArea: "Building Materials",
        svp:"Bowman",
        gm:"NA",
        dfm:"Ken Johnson",
        soma:"Philip Sadler",
        dfmldap:"KXJ3FFP",
        somaldap:"PXS4DZT",
        olap:"D26P  C01 - PIPE/FTNGS"
    }, {
        depnumber: 26,
        depname: "PLUMBING",
        subdepno: "26P",
        subdepname: "PLUMBING",
        classno: "1",
        classname: "PIPE AND FITTINGS",
        subclassnumber: "2",
        subclassname: "PVC PIPE",
        subclassnbr: "26P:1:2",
        businessArea: "Building Materials",
        svp:"Bowman",
        gm:"NA",
        dfm:"Ken Johnson",
        soma:"Philip Sadler",
        dfmldap:"KXJ3FFP",
        somaldap:"PXS4DZT",
        olap:"D26P  C01 - PIPE/FTNGS"
    }, {
        depnumber: 26,
        depname: "PLUMBING",
        subdepno: "26P",
        subdepname: "PLUMBING",
        classno: "1",
        classname: "PIPE AND FITTINGS",
        subclassnumber: "2",
        subclassname: "PVC PIPE",
        subclassnbr: "26P:1:2",
        businessArea: "Building Materials",
        svp:"Bowman",
        gm:"NA",
        dfm:"Ken Johnson",
        soma:"Philip Sadler",
        dfmldap:"KXJ3FFP",
        somaldap:"PXS4DZT",
        olap:"D26P  C01 - PIPE/FTNGS"
    }, {
        depnumber: 26,
        depname: "PLUMBING",
        subdepno: "26P",
        subdepname: "PLUMBING",
        classno: "1",
        classname: "PIPE AND FITTINGS",
        subclassnumber: "2",
        subclassname: "PVC PIPE",
        subclassnbr: "26P:1:2",
        businessArea: "Building Materials",
        svp:"Bowman",
        gm:"NA",
        dfm:"Ken Johnson",
        soma:"Philip Sadler",
        dfmldap:"KXJ3FFP",
        somaldap:"PXS4DZT",
        olap:"D26P  C01 - PIPE/FTNGS"
    }, {
        depnumber: 26,
        depname: "PLUMBING",
        subdepno: "26P",
        subdepname: "PLUMBING",
        classno: "1",
        classname: "PIPE AND FITTINGS",
        subclassnumber: "2",
        subclassname: "PVC PIPE",
        subclassnbr: "26P:1:2",
        businessArea: "Building Materials",
        svp:"Bowman",
        gm:"NA",
        dfm:"Ken Johnson",
        soma:"Philip Sadler",
        dfmldap:"KXJ3FFP",
        somaldap:"PXS4DZT",
        olap:"D26P  C01 - PIPE/FTNGS"
    }, {
        depnumber: 26,
        depname: "PLUMBING",
        subdepno: "26P",
        subdepname: "PLUMBING",
        classno: "1",
        classname: "PIPE AND FITTINGS",
        subclassnumber: "2",
        subclassname: "PVC PIPE",
        subclassnbr: "26P:1:2",
        businessArea: "Building Materials",
        svp:"Bowman",
        gm:"NA",
        dfm:"Ken Johnson",
        soma:"Philip Sadler",
        dfmldap:"KXJ3FFP",
        somaldap:"PXS4DZT",
        olap:"D26P  C01 - PIPE/FTNGS"
    }, {
        depnumber: 26,
        depname: "PLUMBING",
        subdepno: "26P",
        subdepname: "PLUMBING",
        classno: "1",
        classname: "PIPE AND FITTINGS",
        subclassnumber: "2",
        subclassname: "PVC PIPE",
        subclassnbr: "26P:1:2",
        businessArea: "Building Materials",
        svp:"Bowman",
        gm:"NA",
        dfm:"Ken Johnson",
        soma:"Philip Sadler",
        dfmldap:"KXJ3FFP",
        somaldap:"PXS4DZT",
        olap:"D26P  C01 - PIPE/FTNGS"
    }, {
        depnumber: 26,
        depname: "PLUMBING",
        subdepno: "26P",
        subdepname: "PLUMBING",
        classno: "1",
        classname: "PIPE AND FITTINGS",
        subclassnumber: "2",
        subclassname: "PVC PIPE",
        subclassnbr: "26P:1:2",
        businessArea: "Building Materials",
        svp:"Bowman",
        gm:"NA",
        dfm:"Ken Johnson",
        soma:"Philip Sadler",
        dfmldap:"KXJ3FFP",
        somaldap:"PXS4DZT",
        olap:"D26P  C01 - PIPE/FTNGS"
    },{
        depnumber: 26,
        depname: "PLUMBING",
        subdepno: "26P",
        subdepname: "PLUMBING",
        classno: "1",
        classname: "PIPE AND FITTINGS",
        subclassnumber: "2",
        subclassname: "PVC PIPE",
        subclassnbr: "26P:1:2",
        businessArea: "Building Materials",
        svp:"Bowman",
        gm:"NA",
        dfm:"Ken Johnson",
        soma:"Philip Sadler",
        dfmldap:"KXJ3FFP",
        somaldap:"PXS4DZT",
        olap:"D26P  C01 - PIPE/FTNGS"
    }, {
        depnumber: 26,
        depname: "PLUMBING",
        subdepno: "26P",
        subdepname: "PLUMBING",
        classno: "1",
        classname: "PIPE AND FITTINGS",
        subclassnumber: "2",
        subclassname: "PVC PIPE",
        subclassnbr: "26P:1:2",
        businessArea: "Building Materials",
        svp:"Bowman",
        gm:"NA",
        dfm:"Ken Johnson",
        soma:"Philip Sadler",
        dfmldap:"KXJ3FFP",
        somaldap:"PXS4DZT",
        olap:"D26P  C01 - PIPE/FTNGS"
    }, {
        depnumber: 26,
        depname: "PLUMBING",
        subdepno: "26P",
        subdepname: "PLUMBING",
        classno: "1",
        classname: "PIPE AND FITTINGS",
        subclassnumber: "2",
        subclassname: "PVC PIPE",
        subclassnbr: "26P:1:2",
        businessArea: "Building Materials",
        svp:"Bowman",
        gm:"NA",
        dfm:"Ken Johnson",
        soma:"Philip Sadler",
        dfmldap:"KXJ3FFP",
        somaldap:"PXS4DZT",
        olap:"D26P  C01 - PIPE/FTNGS"
    }, {
        depnumber: 26,
        depname: "PLUMBING",
        subdepno: "26P",
        subdepname: "PLUMBING",
        classno: "1",
        classname: "PIPE AND FITTINGS",
        subclassnumber: "2",
        subclassname: "PVC PIPE",
        subclassnbr: "26P:1:2",
        businessArea: "Building Materials",
        svp:"Bowman",
        gm:"NA",
        dfm:"Ken Johnson",
        soma:"Philip Sadler",
        dfmldap:"KXJ3FFP",
        somaldap:"PXS4DZT",
        olap:"D26P  C01 - PIPE/FTNGS"
    }];



function ReferenceMapping() {
    return( 
    <>
     <div className="referenceMapping">
        <BootstrapTable data = { products }  keyField='id' data={ products } columns={ columns } striped
  hover condensed pagination={ paginationFactory() }></BootstrapTable > 
     </div>
       
    </>  
    );
}

export default ReferenceMapping;