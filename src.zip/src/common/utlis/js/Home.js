import React from "react";

function Home(){
    return (
        <h5>Home page</h5>
    )
}
export default Home;