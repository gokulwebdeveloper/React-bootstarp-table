import React from 'react';
import { Link } from "react-router-dom";
function SideBar() {
    return (
        <div className="sidebar">      
            <nav>
                <ul className="list-unstyled components">
                    <li className="active">
                        <Link to="/" data-toggle="collapse" aria-expanded="false"  className="dropdown-toggle">Reference Mapping</Link>
                        <div>
                            <ul className="collapse list-unstyled" id="homeSubmenu">
                                <li>
                                    <Link to="/">Reference Mapping</Link>
                                </li>
                            </ul>
                        </div>
                    </li>

                </ul>
            </nav>
        </div>
    );
}

export default SideBar;