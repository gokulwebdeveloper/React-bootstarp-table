import React from "react";

function User(){
    return (
        <h5>User Info</h5>
    )
}
export default User;