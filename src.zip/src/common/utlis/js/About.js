import React from "react";

function About(){
    return (
        <h5>About User</h5>
    )
}
export default About;